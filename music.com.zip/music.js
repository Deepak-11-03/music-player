const allSongs=[
    {
        name:'har har shambhu',
        img:'image-1',
        src:'music-1'
    },
    {
        name:'Bholenath ji',
        img:'image-2',
        src:'music-2'
    },
    {
        name:' 295-Sidhu moosewala',
        img:'image-3',
        src:'music-3'
    },
    {
        name:'Srivalli',
        img:'image-3',
        src:'music-4'
    },
    {
        name:'Saami Saami',
        img:'image-3',
        src:'music-5'
    },
    {
        name:'Raatan Lambiyan',
        img:'image-3',
        src:'music-6'
    },
    {
        name:'Skechers',
        img:'image-3',
        src:'music-7'
    },
    {
        name:'kesariya',
        img:'image-3',
        src:'music-8'
    }
]